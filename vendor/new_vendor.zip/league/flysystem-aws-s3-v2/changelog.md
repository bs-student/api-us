# Changelog

## 1.0.3 - 2015-10-15

### Improved

* [listContents] Non-recursive listings now use the delimiter option to ensure a shallow listing is returned.

## 1.0.2 - 2015-05-19

### Fixed

* [rename]